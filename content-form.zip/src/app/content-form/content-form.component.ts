import { Component } from '@angular/core';
import { FormBuilder,FormControl, FormGroup, Validators, FormsModule } from '@angular/forms';
import { UsersDataService } from '../services/users-data.service';
@Component({
  selector: 'app-content-form',
  templateUrl: './content-form.component.html',
  styleUrls: ['./content-form.component.css']
})
export class ContentFormComponent {
  
  contentForm = new FormGroup({
    title: new FormControl ('', [Validators.required]),
       body:new FormControl ('', [Validators.required]),
      imageUrl: new FormControl('', [Validators.required]),

  })
  users:any;
   constructor(private userData: UsersDataService){
    this.userData.users().subscribe((data) =>{
      this.users=data;
    })
   }
get title(){
  return this.contentForm.get('title')
}
get body(){
  return this.contentForm.get('body')
}
get imageUrl(){
  return this.contentForm.get('imageUrl')
}
 
  getValue(data: any){
    this.userData.saveUsers(data).subscribe((result)=>{
      console.warn(result)
    })
  }
}


