  import { NgModule } from '@angular/core';
  import { BrowserModule } from '@angular/platform-browser';
  import { MatSlideToggleModule } from '@angular/material/slide-toggle';
  import {FormsModule} from '@angular/forms'
  import { AppComponent } from './app.component';
  //import { HeaderComponent } from './header/header.component';
 // import { BasicFormComponent } from './basic-form/basic-form.component';
  import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
  import { MatButtonToggleModule } from '@angular/material/button-toggle';
//import { TodoListComponent } from './todo-list/todo-list.component';
//import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import {ReactiveFormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http';
import { ContentFormComponent } from './content-form/content-form.component'

  @NgModule({
    declarations: [
      AppComponent,
      // HeaderComponent,
      // BasicFormComponent,
      // TodoListComponent,
      // ReactiveFormComponent,
      ContentFormComponent,
    
      
    ],
    imports: [
      BrowserModule,
      FormsModule,
      NgbModule,
      MatSlideToggleModule,
      MatButtonToggleModule,
      ReactiveFormsModule,
      HttpClientModule
    ],
    providers: [],
    bootstrap: [AppComponent]
  })
  export class AppModule { }
