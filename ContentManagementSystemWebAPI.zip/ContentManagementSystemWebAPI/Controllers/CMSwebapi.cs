﻿using ContentManagementSystemWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ContentManagementSystemWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CMSwebapi : ControllerBase
    {
        private readonly ContentManagementSystemContext context;

        public CMSwebapi(ContentManagementSystemContext context)
        {
            this.context = context;
        }

        [HttpGet]

        public async Task<ActionResult<List<Article>>> GetData()
        {
            var data = await context.Articles.ToListAsync();

            return Ok(data);
        }

        
    }
}
